package inner;

interface Abc{
    void show();
}