package inner;

class Anon{
    public static void main(String args[]){
        Abc ob =new Abc(){
            public void show(){
                System.out.println("hello ");
            }
        };
        ob.show();
    }
}