package Interf;

public class Monster implements Enemy,villian{
    public void attack (){
        System.out.println("attack by monster");
    }
    public void destroy(){
        System.out.println("40% destroyed");
        harm();
    }
    public void harm(){
        System.out.println("Harmed");
    }
}