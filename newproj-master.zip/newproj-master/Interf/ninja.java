package Interf;

class ninja implements Enemy{
    public void attack (){
        System.out.println("attack by ninja");
    }
}