package Interf;

public class MyGame {
    public static void main(String args[]){
        Enemy e;
        e=new ninja();
        e.attack();
        e.destroy();
        e=new Monster();
        e.attack();
        e.destroy();
        Enemy.showInfo();
        //harm();
    }
}