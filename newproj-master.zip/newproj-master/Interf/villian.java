package Interf;
interface villian{
    public void harm();
}