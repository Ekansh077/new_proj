package Questions;
import java.util.*;
public class Q1 {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter size of Array then values:");
        int n=sc.nextInt();
        String ar[]=new String[n];
        for (int i=0;i<n;i++){
            ar[i]=sc.next();
        }
        HashMap<String,String> hs=new HashMap<>();
        for(String a:ar){
            hs.put(a.substring(0, 3).toUpperCase(), a);
        }
        hs.forEach((k,v)->System.out.println(k+" : "+v));
    }
}
