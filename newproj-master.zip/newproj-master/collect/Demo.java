package collect;

import java.util.*;
public class Demo {
    public static void main(String args[]){
        List items=new ArrayList();
        items.add(10);
        items.add("Abc");
        items.add("DEF");
        items.add(9.9);
        items.add(true);

        items.remove(1);
        items.remove((Object)10);

        for(Object ob:items){
            System.out.println(ob);
        }
    }
}
