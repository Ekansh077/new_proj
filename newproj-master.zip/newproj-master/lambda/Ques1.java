package lambda;

public class Ques1 {
    public static void main(String args[]){
        addSpace obj1=(s)->{
            String ret="";
            for(int i=0;i<s.length();i++){
                ret+=s.charAt(i)+" ";
            }
            return ret.trim();
        };
        String newStr=obj1.insert("CGG");
        System.out.println("String after adding spaces : "+newStr);

        Form obj2=(s)->{
            String ret="";
            s=" "+s;
            for(int i=0;i<s.length()-1;i++){
                if(s.charAt(i)==' '){
                    ret=ret+s.charAt(i+1)+".";
                }
            }
            return ret;
        };
        String dot=obj2.shortForm("Indian Railways");
        System.out.println("Short form : "+dot);

    }
}
