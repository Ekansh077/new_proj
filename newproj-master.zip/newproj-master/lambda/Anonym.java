package lambda;
public class Anonym {
    public static void main(String args[]){
        Myinterface ob =()->System.out.println("hello ");
        ob.show();

        Printable pob=x->System.out.println("Value : "+x);
        pob.print(5);
    }
}
