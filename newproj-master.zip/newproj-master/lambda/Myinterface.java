package lambda;

interface Myinterface{
    void show();
}
interface Printable{
    void print(int x);
    default void foo(){
        System.out.println("Hello world");
    }
}