package lambda;
import java.util.*;
public class Ques3 {
    public static void main(String args[]){
        Pass ob=(s1,s2)->{
            if(s1.equals("root") && s2.equals("root")){
                return true;
            }
            return false;
        };
        Scanner sc=new Scanner(System.in);
        String uid=sc.next();
        String pswd=sc.next();
        boolean aut=ob.check(uid,pswd);
        if(aut)
            System.out.println("login success");
        else
            System.out.println("login failed");
    }
}
