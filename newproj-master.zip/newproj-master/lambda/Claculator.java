package lambda;
public class Claculator {
    public static void main(String args[]){

    MathOp addOp= (x,y)->x+y;
    int res=addOp.calculate(10,15);
    System.out.println(res);

    MathOp mulOp= (x,y)->x*y;
    int resmul=mulOp.calculate(10,15);
    System.out.println(resmul);

    
    MathOp findlargeOp= (x,y)->{
        if(x>y) return x;
        else return y;
    };
    int largeOpres=findlargeOp.calculate(10,15);
    System.out.println(largeOpres);
    }
}
