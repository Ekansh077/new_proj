package lambda;

interface MathOp{
    int calculate(int x,int y);
}
