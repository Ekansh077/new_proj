package lambda;

interface addSpace{
    String insert(String s);
}
interface Form{
    String shortForm(String s);
}
interface Pass{
    boolean check(String a,String b);
}