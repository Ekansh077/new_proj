package StreamAPi;
import java.util.*;
import java.util.stream.*;
public class st3 {
    public static void main(String args[]){
        //Method 2
        List<String> namesList=Arrays.asList("abc","bca","cab","def","edf");
        Stream<String> nameStream=namesList.stream();
        //find all names starting with c and convert to uppercase
        //nameStream.map(name->name.toUpperCase())
        //    .filter(name->name.startsWith("C"))
        //   .forEach(name->System.out.println(name));

        //find all names that contain 'c'
        //nameStream.filter(name->name.toLowerCase().contains("c"))
        //        .sorted()
        //        .forEach(name->System.out.println(name));

        //nameStream.filter(name->name.toLowerCase().contains("c"))
         //       .sorted(Collections.reverseOrder())
          //      .forEach(name->System.out.println(name));

        nameStream.filter(name->name.toLowerCase().contains("c"))
                .sorted((s1,s2)->s2.compareTo(s1))
                .forEach(name->System.out.println(name));
    }
}
