package StreamAPi;
import java.util.*;
import java.util.stream.*;
public class st1 {
    public static void main(String args[]){
        // Stream<Integer> numStream=Stream.of(1,2,3,4,5);
        // numStream.forEach(items->System.out.println(items));

        //Method 2
        List<String> namesList=Arrays.asList("abc","bca","cab","def","edf");
        Stream<String> nameStream=namesList.stream();
        nameStream.forEach(items->System.out.println(items));
        //Filtering 
        //find names tht start with c
        //nameStream.filter(name->name.startsWith("c")).forEach(name->System.out.println(name));
    }
}
