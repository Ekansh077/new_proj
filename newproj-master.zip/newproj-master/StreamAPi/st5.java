package StreamAPi;

import java.util.Arrays;
import java.util.stream.*;
import java.util.*;

public class st5 {
    public static void main(String args[]){
        //List<Integer> num=Arrays.asList(1,2,3,4,5);

        //int result = num.stream().filter(n->n%2!=0)
        //    .mapToInt(n->n*n).min().getAsInt();
        // collect all names that start with 'c' to another list
        List<String> namesList=Arrays.asList("abc","bca","cab","def","edf");
        List<String> newlist=namesList.stream().filter(name->name.startsWith("c"))
            .collect(Collectors.toList());

        newlist.forEach(name->System.out.println(name));
        //System.out.println(result);
    }
    
}
