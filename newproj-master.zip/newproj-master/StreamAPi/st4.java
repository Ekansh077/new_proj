package StreamAPi;

import java.util.Arrays;
import java.util.*;

public class st4 {
    public static void main(String args[]){
        List<Integer> num=Arrays.asList(1,2,3,4,5);
        //int result = num.stream().filter(n->n%2==0).reduce(0,(sum,n)->sum+n);

//        int result = num.stream().map(n->n*n)
  //          .reduce(0,(sum,n)->sum+n);
  
// sum of squares
        // int result = num.stream().mapToInt(n->n*n).sum();

        //odd numbers square and find min
        int result = num.stream().filter(n->n%2!=0)
            .mapToInt(n->n*n).min().getAsInt();

        System.out.println(result);
    }
    
}
