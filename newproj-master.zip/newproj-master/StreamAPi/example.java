package StreamAPi;

import java.util.*;

public class example {
    public static void main(String args[]){
        //Find all even numbers from array
        //square the numbers and add them 
        //int numbers[]={10,5,2,7,4,3};
        List<Integer> nums=Arrays.asList(10,5,2,7,4,3);
        int sum=nums.stream().filter(i->i%2==0).map(i->i*i).reduce((x,y)->x+y).get();
        System.out.println("Sum : "+sum);
    }
}
        /*
        int even[]=new int[numbers.length];
        int j=0;
        for(int i=0;i<numbers.length;i++){
            if(numbers[i]%2==0){
                even[j++]=numbers[i];
            }
        }
        int sqs[]=new int[j];
        int sum=0;
        for (int i=0;i<j;i++){
            sqs[i]=even[i]*even[i];
            sum+=sqs[i];
        }
        */