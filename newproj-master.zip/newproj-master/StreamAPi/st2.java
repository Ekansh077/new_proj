package StreamAPi;
import java.util.*;
import java.util.stream.*;
public class st2 {
    public static void main(String args[]){
        //Method 2
        List<String> namesList=Arrays.asList("abc","bca","cab","def","edf");
        Stream<String> nameStream=namesList.stream();
        //Filtering 
        //find names tht start with c
        //nameStream.filter(name->name.startsWith("c")).forEach(name->System.out.println(name));

        //mapping data
        //convert all to upper case
        nameStream.map(name->name.toUpperCase()).forEach(name->System.out.println(name));

    }
}
